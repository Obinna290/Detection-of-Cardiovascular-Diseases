import numpy as np
import joblib as joblib

data_min = {'age': 29.0,
 'sex': 0.0,
 'cp': 1.0,
 'trestbps': 94.0,
 'chol': 100.0,
 'fbs': 0.0,
 'restecg': 0.0,
 'thalach': 71.0,
 'exang': 0.0,
 'oldpeak': 0.0,
 'slope': 1.0,
 'ca': 0.0,
 'thal': 3.0}

data_max = {'age': 77.0,
 'sex': 1.0,
 'cp': 4.0,
 'trestbps': 200.0,
 'chol': 564.0,
 'fbs': 1.0,
 'restecg': 2.0,
 'thalach': 202.0,
 'exang': 1.0,
 'oldpeak': 6.2,
 'slope': 3.0,
 'ca': 3.0,
 'thal': 7.0}

def generate():

    data = []

    for min_value ,max_value in zip(data_min.values(), data_max.values()):

        a = np.arange(min_value, max_value)
        a = np.random.choice(a)

        data.append(a)

    print(data)

    return data

# generate()
# MOdel

model = joblib.load("models/knn.pkl")
minmaxscaler = joblib.load("models/minmaxscaler.pkl")

def makePredictions(data):

    pipe_data = minmaxscaler.transform([data])
    print(pipe_data)
    pred = model.predict(pipe_data).item()

    return pred


