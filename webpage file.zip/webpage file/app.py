import streamlit as st
from validator import *
from utils import generate, data_max, makePredictions

st.set_page_config(page_title="Bug report", page_icon="🫀", layout="wide")

st.title("🫀 Heart Health!")

generate_button = st.button('Generate')

left, right = st.columns((2,2), gap="medium")


## 1
input_data = []

with left:
    left.subheader("Fill in the data...")
   
    form = st.form(key='left-form')

    name = form.text_input('Patient\'s name')
    name = name if name != '' else 'Anonymous'
    
    age = form.text_input('Age')
    age = age if age != '' else 29

    sex = alpha_val(form.selectbox(
        "Sex",
        ("Female","Male"),
        ).lower())

    chest_pain_type = alpha_val(form.selectbox(
        "cp :: Chest Pain type",
        ("typical angina", "atypical angina", "non-anginal pain", "asymptomatic"),
        ).lower())

    trestbps = numeric_val(form.text_input('trestbps :: Resting blood pressure (in mm Hg on admission to the hospital'))
    
    chol = numeric_val(form.text_input('chol :: serum cholestoral in mg/dl'))


    fbs = alpha_val(form.selectbox(
    'fbs :: (fasting blood sugar > 120 mg/dl)',
    ("True","False"),
    ).lower())


## 2
# with middle:
    restecg = alpha_val(form.selectbox(
        "restecg :: resting electrocardiographic results",
        ("normal",
        "having ST-T wave abnormality (T wave inversions and/or ST elevation or depression of > 0.05 mV",
         "showing probable or definite left ventricular hypertrophy by Estes' criteria")).lower())

    thalach = numeric_val(form.text_input('thalach :: maximum heart rate achieved'))

    exang = alpha_val(form.selectbox(
        "exang :: exercise induced angina",
        ("Yes","No"),
        ).lower())

    oldpeak = numeric_val(form.text_input('oldpeak :: ST depression induced by exercise relative to rest'))

    slope = alpha_val(form.selectbox(
      'slope :: the slope of the peak exercise ST segment',
       ("upsloping","flat", "downsloping")).lower())

    ca = form.selectbox(
      'slope :: the slope of the peak exercise ST segment',
       ('0','1','2'))

    thal = alpha_val(form.selectbox(          
     'thal :: 3 = normal; 6 = fixed defect; 7 = reversable defect',
       ("Normal","Fixed defect", "Reversable defect")).lower())
    

    columns =[age, sex, chest_pain_type, trestbps, chol, fbs, restecg, thalach,
        exang, oldpeak, slope, ca, thal]

    submit = form.form_submit_button('Submit')



## 3
with right:

    if submit:
        right.write("Here's your results: ")

        
        st.write(f'Result of {name}')

        clean_d = [0 for _ in range(len(columns))]
        
        for idx, item in enumerate(range(len(columns))):

            c = columns[item]

            if idx in [1,2,5,6,8,10,11,12]:
                print(idx,c)
                clean_d[idx] = check[c]
            else:
                clean_d[idx] = float(c)

        results = makePredictions(clean_d)

        if results == 0:
            st.success("Anonymous, Has a Healthy heart!")

        else:
            st.warning("Anonymous, Does not have a Healthy heart!")


    elif generate_button:
        right.write("Here's your results: ")


        st.write(f'Result of Anonymous!')


        gen_data = generate()

        d = {k:v for k, v in zip(data_max.keys(), gen_data)}

        st.markdown(f'{d}')
        results = makePredictions(gen_data)

        if results == 0:
            st.success("Anonymous, Has a Healthy heart!")

        else:
            st.warning("Anonymous, Does not have a Healthy heart!")