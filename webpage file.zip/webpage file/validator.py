def alpha_val(t):
    if t == '': return 0
    # else: return t
    return t

def numeric_val(t):
    if t == '': return 0
    # else: return t

    return t


check = {

    # sex
    'male': 0,
    'female': 1,

    # cp
    'typical angina': 1,
    'atypical angina': 2,
    'non-anginal pain': 3,
    'asymptomatic': 4,

    # fbs
    'true': 1,
    'false': 0,

    # restecg
    'normal': 0,
    'having ST-T wave abnormality (T wave inversions and/or ST elevation or depression of > 0.05 mV)'.lower(): 1,
    "showing probable or definite left ventricular hypertrophy by Estes' criteria".lower(): 2,

    # exang
    'yes': 1,
    'no': 0,

    # slope
    'upsloping': 0,
    'flat': 1,
    'downsloping': 2,

    # ca
    '0': 0,
    '1': 1,
    '2': 2,

    # thal
    'Normal'.lower(): 3,
    'fixed defect': 6,
    'reversable defect':7,
}